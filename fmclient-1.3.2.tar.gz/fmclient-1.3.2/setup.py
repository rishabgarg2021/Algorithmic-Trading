from setuptools import setup
from setuptools import find_packages

setup(
    name='fmclient',
    packages=find_packages(exclude=['extras', 'fmadmin']),
    # Exclude admin module from distribution
    exclude_package_data={'': ['admin.py']},
    package_data={'fmclient': '*.ini'},
    version='1.3.2',
    description='Library to interact with flexemarkets platform.',
    author='Brain, Mind, and Markets Lab. The University of Melbourne',
    author_email="nitin.yadav@unimelb.edu.au",
    license='BMM Lab ©',
    url="bmmlab.org",
    python_requires='~=3.6',
    install_requires=['asyncio==3.4.3', 'aiohttp==3.3.0', 'autobahn==18.5.2', 'pytz==2018.4', 'asyncio-extras==1.3.0'],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Programming Language :: Python :: 3.6'
    ]
)
