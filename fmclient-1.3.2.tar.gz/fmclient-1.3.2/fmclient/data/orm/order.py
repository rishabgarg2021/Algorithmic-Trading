from enum import Enum


class Order(object):
    def __init__(self, price, units, type, side, market, date=None, id=None, ref=None):
        """
        A class to abstract the order entity for the exchange.
        :param price: price of a single unit in cents.
        :param units: number of units.
        :param type: type of order (currently only LIMIT orders are allowed).
        :param side: side of the order, BUY or SELL.
        :param date: date of order creation (controlled by exchange).
        :param id: order id (controlled by exchange).
        :param ref: internal reference for the order.
        """
        self._price = price
        self._units = units
        self._type = type
        self._side = side
        self._date = date
        self._id = id
        self._market = market
        self._mine = False
        self._ref = ref
        self._market_prefix = "/markets/"
        self._original = None
        self._check()

    def _check(self):
        """
        Check that we have a legal order.
        That is, the price and units are positive integers for limit order with either Buy or Sell side.
        :return:
        """
        assert isinstance(self._price, int)
        assert self._price >= 0
        assert isinstance(self._units, int)
        assert self._units > 0
        assert self._side == OrderSide.BUY or self._side == OrderSide.SELL
        assert self._type == OrderType.LIMIT or self._type == OrderType.CANCEL
        assert isinstance(self._market, int)
        assert self._market > 0

    @property
    def ref(self):
        return self._ref

    @ref.setter
    def ref(self, value):
        self._ref = value

    @property
    def mine(self):
        return self._mine

    @mine.setter
    def mine(self, value):
        self._mine = value

    @property
    def market_id(self):
        return self._market

    @property
    def market(self):
        return self._market_prefix + str(self._market)

    @market.setter
    def market(self, value):
        self._market = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        self._price = value

    @property
    def units(self):
        return self._units

    @units.setter
    def units(self, value):
        self._units = value

    @property
    def type(self):
        return self._type

    @type.setter
    def type(self, value):
        self._type = value

    @property
    def side(self):
        return self._side

    @side.setter
    def side(self, value):
        self._side = value

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, value):
        self._date = value

    @property
    def id(self):
        return self._id or "NoID"

    @id.setter
    def id(self, value):
        self._id = value

    @property
    def original(self):
        return self._original

    @original.setter
    def original(self, value):
        self._original = value

    def __str__(self):
        whose = "Mine"
        if not self._mine:
            whose = "Others"
        output = "".join(
            [str(self.market_id), ":", str(self.id), ":[", self._type.name, "]:", whose, ":", str(self._side.name), ":",
             str(self._units), "@", str(self._price)])
        if self._ref is not None:
            output += ":REF" + str(self._ref)
        return output

    def __repr__(self):
        return self.__str__()


class OrderSide(Enum):
    BUY = 1
    SELL = -1


class OrderType(Enum):
    CANCEL = 0
    LIMIT = 1
