"""
A session entity with supporting classes
"""

from enum import Enum


class SessionState(Enum):
    INIT = -1
    OPEN = 0
    PAUSED = 1
    CLOSED = 2


class Session(object):
    """A Session entity for Marketplaces"""

    def __init__(self, sess_id, sess_state):
        self._id = sess_id
        self._state = SessionState[sess_state]
        self._original = None
        self._name = None
        self._description = None
        self._open_date = None  # "openDate"
        self._close_date = None  # "closeDate"
        # TODO: Perhaps contact server and get all info on this session

    @property
    def id(self):
        return self._id

    @property
    def state(self):
        return self._state

    def __str__(self):
        return "SID:" + str(self._id) + ":" + str(self._state)
