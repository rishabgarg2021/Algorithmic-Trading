"""
Classes and methods to work with holdings
"""


class Holding(object):
    """
    A Holding entity for marketplace. Currently only used by Admin
    """

    def __init__(self, cash: int, market_units: list):
        self._cash = int(cash)
        self._market_units = list(market_units)
        # self._markets = [k for k in market_units.keys()]  # FUTURE: Use a market class here and remove market_units!
        pass

    @property
    def cash(self):
        return self._cash

    @cash.setter
    def cash(self, cash):
        assert cash >= 0
        self._cash = cash

    @property
    def market_units(self):
        return self._market_units

    @property
    def market_units_d(self):
        return {market_unit.item: market_unit.units for market_unit in self.market_units}

    # @market_units.setter
    # def market_units(self, market_units):
    #     self._market_units = market_units

    def __str__(self) -> str:
        return ":".join(["Cash", str(self.cash), "Units", str(self.market_units)])

    def __repr__(self) -> str:
        return self.__str__()


@property
def header():
    pass
