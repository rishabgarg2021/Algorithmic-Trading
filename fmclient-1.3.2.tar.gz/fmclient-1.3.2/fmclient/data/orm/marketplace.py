"""
A marketplace entity with supporting classes
"""
from enum import Enum


class MarketplaceState(Enum):
    OPEN = 0
    PAUSED = 1
    CLOSED = 2
