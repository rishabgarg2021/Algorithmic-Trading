import asyncio
import json
import time
import logging
import logging.config
from autobahn.asyncio.websocket import WebSocketClientProtocol
from autobahn.asyncio.websocket import WebSocketClientFactory
from fmclient.utils import helper as hlp
from fmclient.utils.constants import WS_SIMULATE as SIMULATE


class AgentWebsocketClient(object):
    """
    Class to handle trading agents websocket communication.
    """
    def __init__(self, name, account, email, password, marketplace, address, port, path, queue):
        """
        Initialisation of the class.
        :param name: Name of the trading agent. Useful for logging purposes.
        :param account: Account name for the login.
        :param password: Account password for the login (not used at the moment).
        :param marketplace: Marketplace id for the messages.
        :param address: Address if the websocket connection.
        :param port: Port for the websocket connection.
        :param queue: Queue for incoming messages.
        """
        self._loop = asyncio.get_event_loop()
        self._name = name
        self._account = account
        self._email = email
        self._password = password
        self._marketplace = marketplace
        self._address = address
        self._port = port
        self._path = path
        self._incoming_message_queue = queue
        self._stop = False
        self._logger = None
        self._is_ready = False
        self._waiting_to_join = False
        self._client_protocol = None
        self._channel_id = None
        self._outgoing_message_queue = asyncio.Queue()
        self._setup_logging()

    def _setup_logging(self):
        self._logger = logging.getLogger(".".join(["websocket", hlp.str_shorten(self._email)]))

    def _get_connection_task(self):
        """
        Create the connection task that will connect to the websocket server
        :return:
        """
        factory = WebSocketClientFactory(u"ws://" + str(self._address) + ":" + str(self._port) + self._path)
        factory.protocol = AgentClientProtocol
        task = self._loop.create_connection(factory, self._address, self._port)
        return task

    def setup(self):
        try:
            self._debug("Connecting to {}:{}".format(self._address, self._port))
            connection_task = self._get_connection_task()
            transport, protocol = self._loop.run_until_complete(connection_task)
            self._client_protocol = protocol
            self._client_protocol.set_parent(self)
            asyncio.run_coroutine_threadsafe(self._process_message_queue(), self._loop)
        except ConnectionError:
            self._error("Error connecting to websocket {ws}.".format(ws=self._address))
        except OSError:
            self._error("Connection to websocket {ws} failed.".format(ws=self._address))

    async def _process_message_queue(self):
        """
        Consumer for the outgoing messages to the websocket server.
        Important! We pull a string message to the queue and structure to it (e.g., channel id, command, and time).
        The channel id is only available after joining the appropriate channel on the server. This method waits for
        the channel id to be set (via the _is_ready variable) before sending the messages.
        :return:
        """
        while not self._stop:
            if not self._is_ready:
                asyncio.gather(self._login())
            if self._is_ready and not self._outgoing_message_queue.empty():
                message, msg_type = await self._outgoing_message_queue.get()
                outgoing_message = {
                    "channel_id": self._channel_id,
                    "message": message,
                    "command": "send",
                    "source": "bot",
                    "message_type": msg_type,
                    "time": hlp.time_milli(),  # time.strftime('[%d-%m-%y] %H:%M:%S')}
                }

                self._client_protocol.send_message(outgoing_message)

            await asyncio.sleep(0.2)

    async def _login(self):
        """
        Login to the server and send a join message after the client protocol is connected to the websocket server.
        If we don't wait for the websocket connection, the login message will be lost.
        The join message is essential to pair the messages with the correct "chat room".
        :return:
        """
        # send a login if only we are not already waiting for a previous message
        if not self._waiting_to_join:
            while not self._client_protocol.is_connected:
                await asyncio.sleep(1)

            while not self._is_ready:
                self._waiting_to_join = True
                message = {"command": "join", "source": "robot",
                           "username": self._account + "|" + self._email, "marketplace": self._marketplace}
                self._client_protocol.send_message(message)
                await asyncio.sleep(3)
            self._waiting_to_join = False

    def _logout(self):
        """
        Logout from the server indicating that the bot is about to stop.
        :return:
        """
        # send a login if only we are not already waiting for a previous message
        if self._is_ready:
            message = {"command": "leave", "source": "robot",  "channel_id":self._channel_id,
                           "username": self._account + "|" + self._email, "marketplace": self._marketplace}
            self._client_protocol.send_message(message)

    def send_message(self, message, msg_type):
        """
        Adds the string message to the queue.
        Important! The structuring of the message (e.g., inclusion of channel id, is done in the queue and not here).
        This is because we may be waiting for certain information to create a valid message structure.
        :param message: String message
        :param msg_type: Type of message as string
        :return:
        """
        if not SIMULATE:
            self._outgoing_message_queue.put_nowait((message, msg_type))

    def handle_incoming_message(self, message):
        message = json.loads(message)
        if "join" in message.keys():
            self._channel_id = int(message["join"])
            self._is_ready = True
            self.send_message(self._name + " is connected to websocket server.", "INFO")
            self._debug("Ready to send websocket messages.")
        else:
            self._incoming_message_queue.put_nowait(message)

    def lost_connection(self):
        self._is_ready = False

        async def _re_connect():
            self._debug("Reconnecting to the websocket server.")
            if not self._stop:
                while not self._is_ready:
                    try:
                        connection_task = self._loop.create_task(self._get_connection_task())
                        transport, protocol = await connection_task
                        self._client_protocol = protocol
                        self._client_protocol.set_parent(self)

                        login_task = self._loop.create_task(self._login())
                        await login_task
                    except ConnectionError:
                        # give the server two seconds to start accepting connections again
                        await asyncio.sleep(2)
        asyncio.gather(_re_connect())

    @property
    def stop(self):
        return self._stop

    @stop.setter
    def stop(self, value):
        self._logout()
        self._stop = bool(value)

    def _error(self, msg):
        if self._logger is not None:
            self._logger.error(msg)

    def _debug(self, msg):
        if self._logger is not None:
            self._logger.debug(msg)

    def _info(self, msg):
        if self._logger is not None:
            self._logger.info(msg)


class AgentClientProtocol(WebSocketClientProtocol):
    """
    Class to implement the websocket protocol.
    This class defines the event handlers for incoming and methods for outgoing messages.
    """
    def __init__(self):
        super().__init__()
        self._parent = None
        self._is_connected = False
        self._logger = logging.getLogger("websocket.protocol")

    def set_parent(self, parent):
        self._parent = parent

    @property
    def is_connected(self):
        return self._is_connected

    def onConnect(self, response):
        self._debug("Server connected: {0}".format(response.peer))

    async def onOpen(self):
        self._debug("WebSocket connection open.")
        self._is_connected = True

    def onMessage(self, payload, is_binary):
        if is_binary:
            self._debug("Binary message received: {0} bytes".format(len(payload)))
        else:
            message = payload.decode('utf-8')
            self._parent.handle_incoming_message(message)

    def onClose(self, was_clean, code, reason):
        self._debug("WebSocket connection closed: {0}".format(reason))
        self._is_connected = False
        self._parent.lost_connection()

    def send_message(self, message):
        self._debug("Sending message to ws:" + str(message))
        if not SIMULATE:
            super().sendMessage(json.dumps(message).encode("utf-8"))

    def _error(self, msg):
        if self._logger is not None:
            self._logger.error(msg)

    def _debug(self, msg):
        if self._logger is not None:
            self._logger.debug(msg)

    def _info(self, msg):
        if self._logger is not None:
            self._logger.info(msg)
