"""
An aiohttp session which should persist across all connections made by a robot
"""
import aiohttp
import asyncio

from asyncio_extras import async_contextmanager
from fmclient.fmio.net.fmapi.rest.auth import Auth as FMAuth
from fmclient.utils.logging import FMLogger
from fmclient.utils.singleton import Singleton

# TODO: Reconnect in case of disconnection
# TODO: Agents may have stale data, in which case we may need re-auth

# """How many requests can be performed concurrently"""
concurrency = 1


class FMSession(object, metaclass=Singleton):
    """
    FMSession class encapsulates an :class:`aiohttp.ClientSession` with API server.

    All requests are performed using this session, throughout the application
    """

    CONN_READ_TIMEOUT = 30  # Disable: 0, aiohttp default: 5 * 60

    def __init__(self, loop=None):

        self._logger = FMLogger().get_logger(self.__class__.__name__, "comms")
        try:
            auth = FMAuth().auth
            bearer_auth = FMAuth().bearer_auth
            bearer_auth_header = None
            if bearer_auth:
                bearer_auth_header = {"Authorization": bearer_auth}
                auth = None
        except Exception:
            raise ValueError("Authentication doesn't exist. Make sure you are logged in.")

        if not loop:
            try:
                loop = asyncio.get_event_loop()
            except Exception:
                self._logger.error('Unable to get asyncio event loop.')
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

        self._loop = loop
        self._session = aiohttp.ClientSession(loop=self._loop, auth=auth, headers=bearer_auth_header,
                                              read_timeout=FMSession.CONN_READ_TIMEOUT)
        self._req_count = 0
        self._semaphore = asyncio.Semaphore(concurrency)

    @async_contextmanager
    async def request(self, verb, url, params, data, headers):
        """
        Perform an HTTP request on the underlying :class:`aiohttp.ClientSession`

        :param verb: HTTP verb used to perform this request

        :param url: Absolute URL for this request

        :param params: Parameters hash to be passed

        :param data: Any data to be passed with this request

        :param headers: Any custom headers to be passed with this request

        :return: An :class:`aiohttp.ClientResponse` object
        """
        async with self._semaphore:
            self._req_count += 1
            _req_count = self._req_count

        # return await self._session.request(verb, url, params=params, data=data, headers=headers)
        async with self._session.request(verb, url, params=params, data=data, headers=headers) as resp:
            try:
                self._logger.debug("{:>5} >> Entering FMSession Request".format(_req_count))
                yield resp
            finally:
                self._logger.debug("{:>5} >> Exiting FMSession Request".format(_req_count))
                pass

    def __del__(self):
        """Close the underlying session. Usually done at the end of program"""
        self._session.close()
