import os

'''
Following Environment Variables are in place to configure the library:

FM_HOST(str):  Defines the host address, sans any endpoints
BOT_WS_DOMAIN(str): Defines the domain to use for WS messages, in case routing these messages to a separate host
BOT_WS_PORT(int): Port for the above WS domain
WS_SIMULATE(bool): Whether to only simulate sending messages over WS
'''

# Root URL
FM_ROOT = os.environ.get("FM_HOST", "https://fm-data.herokuapp.com")
API_ROOT = FM_ROOT + "/api"

# Other API Endpoints
MARKETPLACE_URI = "/marketplaces/$id$"
MARKETPLACE_URL = API_ROOT + MARKETPLACE_URI

SESSIONS_URI = "/sessions"
SESSIONS_URL = API_ROOT + SESSIONS_URI

SESSION_URI = "/sessions/$id$"
SESSION_URL = API_ROOT + SESSION_URI

HOLDINGS_EXPORT_URI = MARKETPLACE_URI + "/holdings/downloads?sessions=last"
HOLDINGS_EXPORT_URL = API_ROOT + HOLDINGS_EXPORT_URI

HOLDINGS_IMPORT_URI = MARKETPLACE_URI + "/holdings/uploads"
HOLDINGS_IMPORT_URL = API_ROOT + HOLDINGS_IMPORT_URI

HOLDINGS_CSV_HEADER = "# final holdings -- begin"
HOLDINGS_CSV_FOOTER = "# final holdings -- end"

# Connection Configuration
ASYNCIO_MAX_THREADS = 2

# Agent Reporting and Monitoring Configuration
MONITOR_ORDER_BOOK_DELAY = 2
MONITOR_HOLDINGS_DELAY = 2
MONITOR_SESSION_DELAY = 3

# WebSocket Communication Configuration
WS_SEND_DELAY = 0.5
WS_LISTEN_DELAY = 0.5
WS_MESSAGE_DELAY = 0.5
WS_ADDRESS = os.environ.get("BOT_WS_DOMAIN", "algohost.bmmlab.org")
WS_PORT = os.environ.get("BOT_WS_PORT", 80)
WS_PATH = "/chat/stream/"
WS_SIMULATE = bool(os.environ.get("BOT_WS_SIMULATE", False))

# Miscellaneous Configuration
LOCAL_TIMEZONE = "Australia/Melbourne"
DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
