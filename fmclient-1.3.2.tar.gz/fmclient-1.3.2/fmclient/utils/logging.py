import errno
import logging
import logging.config
import os
import time

from fmclient.utils import helper as hlp
from fmclient.utils.singleton import Singleton


class DynamicFileHandler(logging.FileHandler):
    """This is a Dynamic File Handler for logging module. It creates files with different filename"""

    def __init__(self, path, file_name, mode, agent_name=None, marketplace_id=None):
        """Initialise dynamic file handler with seconds from epoch as file suffix"""

        _suf = time.time() * 10000
        _cur_time_str = time.strftime("[%Y-%m-%d %H:%M:%S %Z]")

        try:
            os.mkdir(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        log_file_name = "-".join([hlp.clean_string(agent_name), marketplace_id, file_name])
        f_path = os.path.join(path, log_file_name)

        super(DynamicFileHandler, self).__init__(f_path, mode)
        self.stream.write(
            "\n=============================== Log Started {} ===============================\n".format(_cur_time_str)
        )


class DynamicFormatter(logging.Formatter):
    """This is a Dynamic Formatter for logging module. It uses different format for different levels"""

    debug_format = '[%(asctime)s:%(name)20s (File "%(pathname)s", line %(lineno)d)]: %(levelname)8s - %(message)s'

    def __init__(self, fmt=None, datefmt=None, style='%'):
        super(DynamicFormatter, self).__init__(fmt, datefmt, style)

    def format(self, record):
        """Formats the string using a detailed format for debug messages, and default format otherwise."""

        # Save the original format configured by the user when the logger formatter was instantiated
        orig_format = self._style._fmt

        # Replace the original format with one customised by logging level
        if record.levelno == logging.DEBUG:
            self._style._fmt = DynamicFormatter.debug_format

        # Call the original formatter class to do the grunt work
        result = super().format(record)

        # Restore the original format configured by the user
        self._style._fmt = orig_format

        return result


class FMLogger(object, metaclass=Singleton):
    """
    This class encapsulates logger for entire library.
    This FMLogger can be used anywhere within the library using the common config

    However, only initialise this logger within a class or a function, but *NOT* at the module level.
    """

    def __init__(self, default_config=None):
        """
        FMLogger initialiser

        :param default_config: Default config dict to be passed for File Handler
        """
        conf_file_location = os.path.normpath(os.path.join(os.path.dirname(__file__), "../logging.ini"))

        if os.path.exists(conf_file_location):
            import configparser
            try:
                logging.config.fileConfig(conf_file_location, defaults=default_config)
            except configparser.Error:
                pass

    def get_logger(self, name, prefix=None):
        """
        Returns a logger from logging module using specified module

        :param name: Name to be used for this logger

        :param prefix: Prefix for this logger. Preferably from the list of loggers defined in logging config file

        :return:
        """
        return logging.getLogger('.'.join([prefix, name]) if prefix else name)
